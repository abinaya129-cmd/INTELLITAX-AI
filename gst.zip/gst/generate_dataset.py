"""
IntelliTax AI — Synthetic GST Dataset Generator
Generates realistic GST dealer data with planted anomalies
"""

import numpy as np
import pandas as pd
import random
import string

np.random.seed(42)
random.seed(42)

N = 1000  # total businesses
ANOMALY_RATE = 0.12  # 12% anomalies

INDUSTRIES = {
    "Manufacturing": {
        "weight": 0.35,
        "elec_per_cr": (8000, 3000),      # kWh per crore turnover
        "freight_ratio": (0.18, 0.06),    # freight / turnover
        "emp_per_cr": (12, 4),            # employees per crore
    },
    "Trading": {
        "weight": 0.40,
        "elec_per_cr": (2000, 800),
        "freight_ratio": (0.10, 0.04),
        "emp_per_cr": (5, 2),
    },
    "Services": {
        "weight": 0.25,
        "elec_per_cr": (1000, 400),
        "freight_ratio": (0.02, 0.01),
        "emp_per_cr": (20, 8),
    },
}

NIC_CODES = {
    "Manufacturing": ["C10", "C13", "C20", "C22", "C24", "C25", "C26", "C28"],
    "Trading":       ["G45", "G46", "G47"],
    "Services":      ["H49", "I55", "J62", "K64", "M69", "M70", "N80"],
}

DISTRICTS = [
    "Chennai", "Coimbatore", "Madurai", "Tiruchirappalli",
    "Salem", "Tirunelveli", "Vellore", "Erode",
    "Thoothukudi", "Dindigul",
]


def generate_gstin(state_code="33"):
    pan = "".join(random.choices(string.ascii_uppercase, k=5))
    pan += "".join(random.choices(string.digits, k=4))
    pan += random.choice(string.ascii_uppercase)
    suffix = str(random.randint(1, 9)) + random.choice(string.ascii_uppercase) + str(random.randint(1, 9))
    return f"{state_code}{pan}{suffix}"


def generate_business(idx, is_anomaly=False, anomaly_type=None):
    industry = random.choices(
        list(INDUSTRIES.keys()),
        weights=[v["weight"] for v in INDUSTRIES.values()]
    )[0]
    cfg = INDUSTRIES[industry]

    # True (expected) turnover in crores
    true_turnover = np.random.lognormal(mean=1.5, sigma=1.0)
    true_turnover = np.clip(true_turnover, 0.5, 200)

    # Operational signals based on true turnover
    elec_mean, elec_std = cfg["elec_per_cr"]
    freight_mean, freight_std = cfg["freight_ratio"]
    emp_mean, emp_std = cfg["emp_per_cr"]

    electricity_kwh = max(500, np.random.normal(elec_mean, elec_std) * true_turnover)
    freight_value = max(0, np.random.normal(freight_mean, freight_std) * true_turnover)
    num_employees = max(1, int(np.random.normal(emp_mean, emp_std) * true_turnover))
    ewaybill_count = max(0, int(np.random.normal(8, 3) * true_turnover))

    # Declared turnover = true turnover (for normal businesses)
    declared_turnover = true_turnover * np.random.normal(1.0, 0.05)  # ±5% noise

    # --- ANOMALY INJECTION ---
    if is_anomaly:
        if anomaly_type == "under_report":
            # High electricity/freight but low declared turnover
            declared_turnover = true_turnover * np.random.uniform(0.25, 0.55)
        elif anomaly_type == "over_report":
            # Low operational signals but high declared turnover
            declared_turnover = true_turnover * np.random.uniform(1.8, 3.0)
            electricity_kwh *= np.random.uniform(0.3, 0.6)
            num_employees = max(1, int(num_employees * np.random.uniform(0.3, 0.6)))
        elif anomaly_type == "ghost_freight":
            # High freight, low everything else → fake e-way bills
            freight_value = true_turnover * np.random.uniform(0.5, 0.9)
            declared_turnover = true_turnover * np.random.uniform(0.3, 0.5)

    declared_turnover = max(0.1, declared_turnover)

    return {
        "gstin": generate_gstin(),
        "district": random.choice(DISTRICTS),
        "industry": industry,
        "nic_code": random.choice(NIC_CODES[industry]),
        "declared_turnover_cr": round(declared_turnover, 4),
        "true_turnover_cr": round(true_turnover, 4),
        "electricity_kwh": round(electricity_kwh, 2),
        "freight_value_cr": round(freight_value, 4),
        "num_employees": num_employees,
        "ewaybill_count": ewaybill_count,
        "is_anomaly": int(is_anomaly),
        "anomaly_type": anomaly_type if is_anomaly else "none",
    }


def main():
    records = []
    n_anomalies = int(N * ANOMALY_RATE)
    n_normal = N - n_anomalies

    anomaly_types = ["under_report", "over_report", "ghost_freight"]

    for i in range(n_normal):
        records.append(generate_business(i, is_anomaly=False))

    for i in range(n_anomalies):
        atype = random.choice(anomaly_types)
        records.append(generate_business(n_normal + i, is_anomaly=True, anomaly_type=atype))

    random.shuffle(records)
    df = pd.DataFrame(records)
    df.reset_index(drop=True, inplace=True)

    # Add derived features
    df["revenue_per_kwh"] = df["declared_turnover_cr"] / (df["electricity_kwh"] / 1000 + 1e-6)
    df["revenue_per_employee"] = df["declared_turnover_cr"] / (df["num_employees"] + 1e-6)
    df["freight_to_turnover_ratio"] = df["freight_value_cr"] / (df["declared_turnover_cr"] + 1e-6)
    df["ewaybill_frequency"] = df["ewaybill_count"] / (df["declared_turnover_cr"] + 1e-6)

    df.to_csv("gst_synthetic_dataset.csv", index=False)
    print(f"✅ Dataset generated: {len(df)} records ({n_anomalies} anomalies)")
    print(df["is_anomaly"].value_counts())
    print(df.head(3))


if __name__ == "__main__":
    main()