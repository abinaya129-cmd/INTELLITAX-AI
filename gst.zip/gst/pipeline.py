"""
IntelliTax AI — Hybrid Anomaly Detection Pipeline
Corrected Version
"""

import pandas as pd
import numpy as np
import json
import os
import warnings

warnings.filterwarnings("ignore")

from sklearn.ensemble import IsolationForest
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import (
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    average_precision_score,
    mean_absolute_error,
    mean_squared_error,
    r2_score
)

import xgboost as xgb

# ─────────────────────────────────────────────────────────────
# PATHS
# ─────────────────────────────────────────────────────────────

DATA_PATH = "gst_synthetic_dataset.csv"
OUTPUT_DIR = "outputs"

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ─────────────────────────────────────────────────────────────
# PARAMETERS
# ─────────────────────────────────────────────────────────────

ALPHA = 0.70
BETA = 0.30
RISK_THRESHOLD = 0.30
CONTAMINATION = 0.12

# ─────────────────────────────────────────────────────────────
# LOAD DATA
# ─────────────────────────────────────────────────────────────

df = pd.read_csv(DATA_PATH)

# Remove spaces from column names
df.columns = df.columns.str.strip()

print("\nAvailable Columns:")
print(df.columns.tolist())

# Automatically detect anomaly column
if 'is_anomaly' in df.columns:
    anomaly_col = 'is_anomaly'
elif 'fraud_flag' in df.columns:
    anomaly_col = 'fraud_flag'
elif 'anomaly' in df.columns:
    anomaly_col = 'anomaly'
else:
    print("\n❌ No anomaly column found.")
    exit()

print(f"\nDataset Loaded Successfully")
print(f"Total Records: {len(df)}")
print(f"Anomalies: {df[anomaly_col].sum()}")

# ─────────────────────────────────────────────────────────────
# ENCODE INDUSTRY
# ─────────────────────────────────────────────────────────────

le = LabelEncoder()
df["industry_enc"] = le.fit_transform(df["industry"])

# ─────────────────────────────────────────────────────────────
# INDUSTRY MEDIANS
# ─────────────────────────────────────────────────────────────

med = df.groupby("industry").agg(
    med_elec=("electricity_kwh", "median"),
    med_freight=("freight_value_cr", "median"),
    med_emp=("num_employees", "median"),
).reset_index()

df = df.merge(med, on="industry", how="left")

# ─────────────────────────────────────────────────────────────
# FEATURE ENGINEERING
# ─────────────────────────────────────────────────────────────

df["rev_per_kwh"] = (
    df["declared_turnover_cr"] /
    (df["electricity_kwh"] + 1)
)

df["rev_per_emp"] = (
    df["declared_turnover_cr"] /
    (df["num_employees"] + 1)
)

df["freight_ratio"] = (
    df["freight_value_cr"] /
    (df["declared_turnover_cr"] + 1)
)

df["eway_per_turnover"] = (
    df["ewaybill_count"] /
    (df["declared_turnover_cr"] + 1)
)

df["elec_vs_ind"] = (
    df["electricity_kwh"] /
    (df["med_elec"] + 1)
)

df["freight_vs_ind"] = (
    df["freight_value_cr"] /
    (df["med_freight"] + 1)
)

df["emp_vs_ind"] = (
    df["num_employees"] /
    (df["med_emp"] + 1)
)

# ─────────────────────────────────────────────────────────────
# FEATURES
# ─────────────────────────────────────────────────────────────

FEATURES = [
    "electricity_kwh",
    "freight_value_cr",
    "num_employees",
    "ewaybill_count",
    "rev_per_kwh",
    "rev_per_emp",
    "freight_ratio",
    "eway_per_turnover",
    "elec_vs_ind",
    "freight_vs_ind",
    "emp_vs_ind",
    "industry_enc",
]

# ─────────────────────────────────────────────────────────────
# TARGETS
# ─────────────────────────────────────────────────────────────

X = df[FEATURES]

y_reg = df["true_turnover_cr"]

y_cls = df[anomaly_col]

# ─────────────────────────────────────────────────────────────
# TRAIN TEST SPLIT
# ─────────────────────────────────────────────────────────────

X_tr, X_te, yr_tr, yr_te, yc_tr, yc_te = train_test_split(
    X,
    y_reg,
    y_cls,
    test_size=0.2,
    random_state=42,
    stratify=y_cls
)

idx_te = X_te.index

# ═════════════════════════════════════════════════════════════
# MODEL 1 — XGBOOST
# ═════════════════════════════════════════════════════════════

print("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
print("MODEL 1: XGBoost Regressor")
print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

xgb_model = xgb.XGBRegressor(
    n_estimators=300,
    max_depth=6,
    learning_rate=0.05,
    subsample=0.8,
    colsample_bytree=0.8,
    reg_lambda=1.5,
    reg_alpha=0.3,
    random_state=42,
    verbosity=0
)

xgb_model.fit(
    X_tr,
    yr_tr,
    eval_set=[(X_te, yr_te)],
    verbose=False
)

y_pred = xgb_model.predict(X_te)

# Metrics
xgb_mae = mean_absolute_error(yr_te, y_pred)

xgb_rmse = np.sqrt(
    mean_squared_error(yr_te, y_pred)
)

xgb_r2 = r2_score(yr_te, y_pred)

print(f"MAE  : {xgb_mae:.4f}")
print(f"RMSE : {xgb_rmse:.4f}")
print(f"R²   : {xgb_r2:.4f}")

# Residual score
res_raw = np.abs(
    df.loc[idx_te, "declared_turnover_cr"].values - y_pred
) / (y_pred + 1)

xgb_score = (
    (res_raw - res_raw.min()) /
    (res_raw.max() - res_raw.min() + 1e-9)
)

# ═════════════════════════════════════════════════════════════
# MODEL 2 — ISOLATION FOREST
# ═════════════════════════════════════════════════════════════

print("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
print("MODEL 2: Isolation Forest")
print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

scaler = StandardScaler()

X_tr_s = scaler.fit_transform(X_tr)
X_te_s = scaler.transform(X_te)

iso = IsolationForest(
    n_estimators=300,
    contamination=CONTAMINATION,
    max_features=0.8,
    bootstrap=True,
    random_state=42
)

iso.fit(X_tr_s)

iso_raw = iso.decision_function(X_te_s)

iso_score = 1 - (
    (iso_raw - iso_raw.min()) /
    (iso_raw.max() - iso_raw.min() + 1e-9)
)

iso_labels = (
    iso.predict(X_te_s) == -1
).astype(int)

print(f"Flagged anomalies: {iso_labels.sum()}")

# ═════════════════════════════════════════════════════════════
# HYBRID MODEL
# ═════════════════════════════════════════════════════════════

print("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
print("HYBRID MODEL")
print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

hybrid_raw = (
    ALPHA * xgb_score +
    BETA * iso_score
)

risk_score = hybrid_raw * 100

flagged = (
    hybrid_raw > RISK_THRESHOLD
).astype(int)

print(f"Hybrid flagged: {flagged.sum()}")

# ═════════════════════════════════════════════════════════════
# EVALUATION FUNCTION
# ═════════════════════════════════════════════════════════════

def eval_clf(name, y_true, y_pred_bin, y_score=None):

    p = precision_score(
        y_true,
        y_pred_bin,
        zero_division=0
    )

    r = recall_score(
        y_true,
        y_pred_bin,
        zero_division=0
    )

    f1 = f1_score(
        y_true,
        y_pred_bin,
        zero_division=0
    )

    cm = confusion_matrix(y_true, y_pred_bin)

    tn, fp, fn, tp = cm.ravel()

    print(f"\n{name}")
    print(f"Precision : {p:.3f}")
    print(f"Recall    : {r:.3f}")
    print(f"F1 Score  : {f1:.3f}")

    return {
        "precision": p,
        "recall": r,
        "f1": f1
    }

# ═════════════════════════════════════════════════════════════
# EVALUATION
# ═════════════════════════════════════════════════════════════

print("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
print("MODEL PERFORMANCE")
print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

eval_clf(
    "Isolation Forest",
    yc_te,
    iso_labels,
    iso_score
)

eval_clf(
    "Hybrid Model",
    yc_te,
    flagged,
    hybrid_raw
)

# ═════════════════════════════════════════════════════════════
# FEATURE IMPORTANCE
# ═════════════════════════════════════════════════════════════

fi = pd.Series(
    xgb_model.feature_importances_,
    index=FEATURES
).sort_values(ascending=False)

print("\nTop Features:")
print(fi)

# ═════════════════════════════════════════════════════════════
# OUTPUT DATAFRAME
# ═════════════════════════════════════════════════════════════

df_out = df.loc[idx_te].copy()

df_out["expected_turnover_cr"] = y_pred
df_out["xgb_score"] = np.round(xgb_score, 4)
df_out["iso_score"] = np.round(iso_score, 4)
df_out["hybrid_raw"] = np.round(hybrid_raw, 4)
df_out["hybrid_score"] = df_out["hybrid_raw"]   # alias kept for compatibility
df_out["risk_score"] = np.round(risk_score, 2)
df_out["flagged"] = flagged

# Risk Levels
bins = [0, 30, 50, 100]
labels = ["Low", "Medium", "High"]

df_out["risk_level"] = pd.cut(
    df_out["risk_score"],
    bins=bins,
    labels=labels
)

# ─────────────────────────────────────────────────────────────
# EXPLANATION, DETECTED ANOMALY TYPE, CONFIDENCE, STATUS
# ─────────────────────────────────────────────────────────────

def build_explanation(row):
    signals = []
    if abs(row["declared_turnover_cr"] - row["expected_turnover_cr"]) > 0.5 * row["expected_turnover_cr"]:
        signals.append("Significant declared-vs-expected gap")
    if row["elec_vs_ind"] > 1.5:
        signals.append("Electricity usage above industry norm")
    if row["freight_vs_ind"] > 1.5:
        signals.append("Freight above industry norm")
    if row["emp_vs_ind"] > 1.5:
        signals.append("Employee count above industry norm")
    if row["iso_score"] > 0.6:
        signals.append("Structural outlier (IF signal)")
    return "; ".join(signals) if signals else "Mild operational mismatch"

def detect_anomaly_type(row):
    if row["flagged"] == 0:
        return "Normal"
    gap = row["declared_turnover_cr"] - row["expected_turnover_cr"]
    # Ghost freight: high freight ratio but low declared
    if row["freight_vs_ind"] > 2.0 and row["declared_turnover_cr"] < row["expected_turnover_cr"]:
        return "Ghost Freight"
    if gap > 0.3 * row["expected_turnover_cr"]:
        return "Over-reporting"
    if gap < -0.3 * row["expected_turnover_cr"]:
        return "Under-reporting"
    return "Normal"

def compute_confidence(row):
    # Base confidence from hybrid_score, scaled to 80–99 range
    base = 80.0 + row["hybrid_score"] * 19.0
    return round(min(base, 99.0), 3)

df_out["explanation"] = df_out.apply(build_explanation, axis=1)
df_out["detected_anomaly_type"] = df_out.apply(detect_anomaly_type, axis=1)
df_out["confidence"] = df_out.apply(compute_confidence, axis=1)

# Status: High/Medium for flagged, Safe for low-risk unflagged
df_out["status"] = df_out.apply(
    lambda r: str(r["risk_level"]) if r["flagged"] == 1 else "Safe", axis=1
)

# ═════════════════════════════════════════════════════════════
# SAVE OUTPUTS
# ═════════════════════════════════════════════════════════════

csv_path = f"{OUTPUT_DIR}/risk_scores.csv"

df_out.to_csv(csv_path, index=False)

# Also save to root folder so daash.html (served from the same dir) can fetch it directly
df_out.to_csv("risk_scores.csv", index=False)

metrics = {
    "mae": round(xgb_mae, 4),
    "rmse": round(xgb_rmse, 4),
    "r2": round(xgb_r2, 4)
}

json_path = f"{OUTPUT_DIR}/metrics.json"

with open(json_path, "w") as f:
    json.dump(metrics, f, indent=2)

print("\n✅ PROCESS COMPLETED")
print(f"CSV Saved  : {csv_path}")
print(f"JSON Saved : {json_path}")