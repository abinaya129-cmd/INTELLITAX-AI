INTELLITAX-AI synthetic GST dataset (gst_dataset27)
=====================================================
Rows: 15000 Tamil Nadu dealers (deterministic seed 42)
Segment mix: Manufacturer 7313, Trader 6048, Logistics 1639

DETECTION MODEL (sector-conditioned — the key change vs v26)
  Manufacturers : electricity + employment + e-way freight define the physical
                  ceiling. The employment signal is deliberately LOW-weighted
                  (max ~20/100 pts alone) so genuine mid-scale manufacturers are
                  never flagged on headcount alone. Fraud = footprint >> declared.
  Traders       : production signals are NOT evidence. Stock / goods movement is
                  verified through GSTR-1 vs GSTR-2A triangulation — a firm that
                  shows PURCHASES without matching SALES (conduit) and a GSTR-1
                  vs GSTR-3B cash divergence (understated turnover) is flagged.
  Logistics     : fleet economics (trips x distance x per-km realisation) imply
                  the revenue floor; freight revenue mismatch is the signal.

ASYMMETRY RULE (v27)
  Only UPWARD gaps are scored (physical/filing evidence >> declared turnover).
  Over-reporters (declared >> footprint) get a consistency note, never points —
  understated turnover is the primary evasion signature, so low declarers are
  treated as the main culprits, not high declarers.

COLUMNS (full_dataset_with_scores.csv)
  gstin                  15-char GSTIN (33 = Tamil Nadu state code)
  businessName           synthetic legal name
  district               one of 16 TN districts (industrial-weight sampling)
  sector                 10 business sectors
  segment                Manufacturer | Trader | Logistics (drives the model)
  regType                Regular | Composite (Composite capped at Rs.1.5 Cr)
  declared               annual turnover declared in GSTR-3B (Rs.)
  gstr1Sales             invoiced outward supplies, GSTR-1 (Rs.)
  gstr3bTurnover         cash returned in GSTR-3B (Rs.)
  purchases              inward supplies visible in GSTR-2A (Rs.)
  taxPaid                net cash GST paid (Rs.)
  itcClaimed / itcRatio  Input Tax Credit claimed and its share of turnover
  filingStatus           Filed on time | Filed late | Non-filer
  monthlyUnits           electricity kWh/month (TANGEDCO-style feed)
  ewayCountMonthly       e-way bills per month
  ewayValueMonthly       goods value moved per month (Rs.)
  headcount, wageBill    EPF/ESI-registered employees and annual wage bill
  impliedElec            revenue implied by power draw (Rs./yr)
  impliedFreight         goods movement value vs revenue (Rs./yr)
  impliedEmp             revenue capacity implied by headcount (Rs./yr)
  fleetImplied           revenue implied by fleet activity (Rs./yr)
  purchaseFlowRatio      GSTR-2A purchases / GSTR-1 sales
  purchaseNoSale         share of purchases with no matching sales (0-1)
  turnoverDivergence     GSTR-1 sales not returned in 3B (0-1)
  riskScore              0-100 engine score (>=60 High, >=30 Medium)
  riskTier               Low / Medium / High Risk
  detectedAnomalyType    engine-assigned typology
  plantedType            ground-truth typology used to generate the row
                         ('none' = compliant draw; used for precision/recall)
  reasons                plain-language explanation, pipe-separated

GROUND TRUTH
  Every 10th row carries a planted typology (plantedType), so precision and
  recall of the scoring kernel can be measured directly from the CSV.
  Detection thresholds: ELE_TOL=0.18, TURN_TOL=0.15, PURCH_TOL=0.25,
  composite band=5% under Rs.1.5 Cr,
  representative GST rate=18%.

ALL DATA IS SYNTHETIC. No real taxpayer, GSTIN, or consumer record is used —
the generator mirrors statistical structure only (responsible-AI by design).
