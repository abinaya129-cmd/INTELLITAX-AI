INTELLITAX-AI synthetic GST dataset (gst_dataset28)
=====================================================
Rows: 15000 Tamil Nadu dealers (deterministic seed 42)
Segment mix: Manufacturer 7260, Trader 6099, Logistics 1641

DETECTION MODEL (sector-conditioned — v28 checkpoint model)
  Manufacturers : ELECTRICITY + EMPLOYEE COUNT only. E-way bills are NOT scored.
                  Fraud = production footprint >> declared turnover.
  Traders       : pure GSTR return triangulation — no e-way, no electricity.
                  THE CHECKPOINT: GSTR-2A purchases - GSTR-3B sales must equal
                  the stock the books claim (proportions must match).
                  buy Rs.20 L -> sell Rs.15 L -> books must show ~Rs.5-7 L stock
                  and PASS; books far below = goods sold off-book; books far
                  above = paper stock propping up ITC. Both are flagged.
  Logistics     : fleet economics (trips x distance x per-km realisation) imply
                  the revenue floor; e-way bills remain descriptive evidence.

ASYMMETRY RULE (all versions)
  Only UPWARD gaps are scored (evidence >> declared turnover). Over-reporters
  get a consistency note, never points — understated turnover is the primary
  evasion signature, so low declarers are treated as the main culprits.

COLUMNS (full_dataset_with_scores.csv)
  gstin                  15-char GSTIN (33 = Tamil Nadu state code)
  businessName           synthetic legal name
  district               one of 16 TN districts (industrial-weight sampling)
  sector                 10 business sectors
  segment                Manufacturer | Trader | Logistics (drives the model)
  regType                Regular | Composite (Composite capped at Rs.1.5 Cr)
  declared               annual turnover declared in GSTR-3B (Rs.)
  gstr1Sales             invoiced outward supplies, GSTR-1 (Rs.)
  gstr3bTurnover         cash returned in GSTR-3B (Rs.)
  purchases              inward supplies visible in GSTR-2A (Rs.)
  taxPaid                net cash GST paid (Rs.)
  itcClaimed / itcRatio  Input Tax Credit claimed and its share of turnover
  filingStatus           Filed on time | Filed late | Non-filer
  monthlyUnits           electricity kWh/month (TANGEDCO-style feed)
  ewayCountMonthly       e-way bills per month (LOGISTICS rows only, else blank)
  ewayValueMonthly       goods value moved per month (Rs., logistics rows only)
  headcount, wageBill    EPF/ESI-registered employees and annual wage bill
  impliedElec            revenue implied by power draw (Rs./yr, manufacturers)
  impliedEmp             revenue capacity implied by headcount (Rs./yr)
  fleetImplied           revenue implied by fleet activity (Rs./yr, logistics)
  bookStock              closing stock the BOOKS claim (Rs.)
  stockBalance           2A purchases - 3B sales: the balance the books must
                         cover (Rs.; negative = net outward during the year)
  stockShort             (balance - books) / purchases, when books fall short
  stockExcess            (books - 1.6x balance) / balance, paper-stock face
  purchaseFlowRatio      GSTR-2A purchases / GSTR-1 sales
  purchaseNoSale         share of purchases with no matching sales (0-1)
  turnoverDivergence     GSTR-1 sales not returned in 3B (0-1)
  riskScore              0-100 engine score (>=60 High, >=30 Medium)
  riskTier               Low / Medium / High Risk
  detectedAnomalyType    engine-assigned typology
  plantedType            ground-truth typology used to generate the row
                         ('none' = compliant draw; used for precision/recall)
  reasons                plain-language explanation, pipe-separated

GROUND TRUTH
  Every 10th row carries a planted typology (plantedType), so precision and
  recall of the scoring kernel can be measured directly from the CSV.
  Detection thresholds: ELE_TOL=0.18, TURN_TOL=0.15, PURCH_TOL=0.25,
  STOCK_TOL=0.06 (cap 0.22), composite band=5%
  under Rs.1.5 Cr, representative GST rate=18%.

ALL DATA IS SYNTHETIC. No real taxpayer, GSTIN, or consumer record is used —
the generator mirrors statistical structure only (responsible-AI by design).
