# 🧾 IntelliTax AI — GST Intelligence Platform

> Hybrid AI-powered anomaly detection for GST dealer compliance — Tamil Nadu  
> Built for the hackathon using XGBoost + Isolation Forest

---

## 🚀 Live Demo (No Setup Needed)

Just double-click `daash.html` — the dashboard opens instantly in your browser with pre-loaded data. No server, no install required.

---

## 📌 What It Does

IntelliTax AI analyses GST dealer data and flags suspicious businesses using a hybrid ML pipeline:

- **Under-reporting** — High electricity/freight but suspiciously low declared turnover
- **Over-reporting** — Inflated turnover with low operational signals
- **Ghost Freight** — High e-way bill activity inconsistent with actual business size

Each flagged dealer gets a **risk score (0–100)**, anomaly type, AI explanation, and confidence level.

---

## 🏗️ Architecture

```
generate_dataset.py  →  gst_synthetic_dataset.csv
        ↓
   pipeline.py        →  risk_scores.csv  +  outputs/metrics.json
        ↓
   daash.html         →  Interactive Dashboard (embedded data)
```

### Models Used

| Model | Role | Weight |
|-------|------|--------|
| XGBoost Regressor | Predicts expected turnover; flags declared vs expected gap | 70% |
| Isolation Forest | Detects structural outliers in operational signals | 30% |
| **Hybrid Score** | `risk_score = (0.70 × xgb + 0.30 × iso) × 100` | — |

---

## 📂 Project Structure

```
gst1/
├── daash.html                  # Dashboard (works standalone)
├── generate_dataset.py         # Synthetic GST data generator
├── pipeline.py                 # ML anomaly detection pipeline
├── gst_synthetic_dataset.csv   # Generated dataset (1000 records)
├── risk_scores.csv             # Pipeline output (200 test records)
├── requirements.txt
├── README.md
└── outputs/
    ├── risk_scores.csv
    └── metrics.json
```

---

## ⚙️ Run It Yourself

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Generate synthetic dataset
```bash
python generate_dataset.py
```
Outputs `gst_synthetic_dataset.csv` with 1000 records (12% anomaly rate).

### 3. Run the ML pipeline
```bash
python pipeline.py
```
Outputs `risk_scores.csv` and `outputs/metrics.json` with model performance.

### 4. Open the dashboard

**Option A — Double-click (easiest)**  
Just open `daash.html` directly in your browser. Uses embedded data.

**Option B — With live CSV**  
```bash
python -m http.server 8000
```
Then open `http://localhost:8000/daash.html`

---

## 📊 Dataset Features

| Feature | Description |
|---------|-------------|
| `declared_turnover_cr` | Self-reported GST turnover (crores) |
| `electricity_kwh` | Electricity consumption (proxy for actual activity) |
| `freight_value_cr` | Freight/logistics spend |
| `num_employees` | Employee headcount |
| `ewaybill_count` | E-way bill transaction count |
| `industry` | Manufacturing / Trading / Services |
| `nic_code` | NIC industry classification code |
| `district` | Tamil Nadu district |

---

## 🎯 Model Performance

| Metric | Value |
|--------|-------|
| XGBoost R² | ~0.85+ |
| Precision | ~0.72 |
| Recall | ~0.68 |
| F1 Score | ~0.70 |

---

## 🖥️ Dashboard Features

- **Overview** — KPI cards, risk distribution charts, district heatmap
- **All Businesses** — Full searchable/filterable table of 200 records
- **Audit Queue** — Flagged anomalies sorted by risk score
- **GSTIN Lookup** — Search any dealer by GSTIN for full AI report
- **Model Info** — Architecture, feature importance, confusion matrix
- **Export** — Download audit queue as CSV or PDF report

---

## 🛠️ Tech Stack

- **ML**: Python, XGBoost, Scikit-learn, Pandas, NumPy
- **Frontend**: Vanilla HTML/CSS/JS, Chart.js, PapaParse
- **Data**: Synthetic GST data modelled on Tamil Nadu industry profiles

---

## 👥 Team

IntelliTax AI — Hackathon Submission  
Tamil Nadu GST Intelligence Platform
